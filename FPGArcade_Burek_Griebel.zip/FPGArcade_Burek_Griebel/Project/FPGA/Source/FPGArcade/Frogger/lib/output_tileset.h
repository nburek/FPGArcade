#ifndef OUTPUT_TILE_SET_H
#define OUTPUT_TILE_SET_H

#include "xgpio.h"
#include "xstatus.h"
#include "joystickLibrary.h"
#include "graphicsLibrary.h"


#define waterTILE 11
#define borderTILE 12
#define dirtTILE1 13
#define dirtTILE2 14
#define dirtTILE3 15
#define dirtTILE4 16

//start function prototypes
void drawBackground();


#endif 
